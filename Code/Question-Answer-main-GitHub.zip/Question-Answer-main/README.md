# Question_answering

# run_squad.py	
main program, create dataset (tokenization and encode), create dataloader, load pretrained model, train model, evaluate model		

# trainer_qa.py	
Training engine		

# utils_qa.py	
Decode prediction, preprocess prediction		

# Advanced_models.py	
Advanced model architecures		

# run_qa_advanced.py	
main program, create dataset (tokenization and encode), create dataloader, load pretrained model, train advanced model, evaluate advanced model		

![This is an image](https://github.com/Ahmedashorit/Question-Answer/blob/main/Advanced-model.png)
